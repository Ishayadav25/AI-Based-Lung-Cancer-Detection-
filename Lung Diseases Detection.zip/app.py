from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import requests as http_requests
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from ultralytics import YOLO
import tempfile
import uuid

# Define categories for the model output
format_dict =  { 0: 'Adenocarcinoma case',
            1: 'Bengin case',
            2: 'Large cell Carcinoma case',
            3: 'Malignant case',
            4: 'Normal case',
            5: 'Squamous cell Carcinoma case'}

DISEASE_INFO = {
    'Adenocarcinoma case': {
        'explanation': 'Adenocarcinoma is a type of non-small cell lung cancer that begins in the glandular cells (which secrete mucus). It is the most common type of lung cancer and is often found in the outer areas of the lungs.',
        'cure': 'Treatment typically involves surgery to remove the tumor if caught early. Advanced stages may require a combination of chemotherapy, targeted drug therapy (focusing on specific genetic mutations like EGFR), immunotherapy, and radiation.'
    },
    'Bengin case': {
        'explanation': 'A benign lung nodule or tumor is a non-cancerous growth. It does not spread to other parts of the body and is usually not life-threatening. Common causes include past bacterial/fungal infections, inflammation, or scar tissue.',
        'cure': 'Often, no medical treatment is necessary. Doctors typically recommend periodic monitoring with CT scans to ensure the nodule does not change in size or shape. If it grows large enough to cause breathing symptoms, it may be surgically removed.'
    },
    'Large cell Carcinoma case': {
        'explanation': 'Large cell carcinoma is a subtype of non-small cell lung cancer characterized by large, abnormal-looking cells. It tends to grow and spread more aggressively than some other forms of lung cancer.',
        'cure': 'Standard treatment strategies include surgical resection (for early stages), chemotherapy, and radiation therapy. Depending on the tumor\'s specific molecular profile, immunotherapy may also be a viable option.'
    },
    'Malignant case': {
        'explanation': 'A malignant lung finding indicates the presence of cancer cells that can invade nearby tissues and spread (metastasize). This is a broad term that encompasses various aggressive lung cancers requiring immediate attention.',
        'cure': 'Management requires a comprehensive oncology approach. Depending on the specific type and stage determined by a biopsy, treatment involves a customized combination of surgery, aggressive chemotherapy, radiation therapy, and immunotherapy.'
    },
    'Normal case': {
        'explanation': 'The imaging scan appears normal, with no visible signs of nodules, tumors, opacities, or significant abnormalities in the lung tissue.',
        'cure': 'No medical treatment is required. Continue maintaining a healthy lifestyle, avoid smoking and secondhand smoke, and consult a healthcare provider for routine check-ups or if any respiratory symptoms develop.'
    },
    'Squamous cell Carcinoma case': {
        'explanation': 'Squamous cell carcinoma is a non-small cell lung cancer that originates in the squamous cells lining the airways (bronchi). It is very strongly linked to a history of smoking and typically arises in the central part of the lungs.',
        'cure': 'Treatment depends heavily on the stage and may involve surgical removal of the affected lung lobe, radiation therapy, and chemotherapy. Immunotherapy drugs are frequently used alongside standard treatments to improve outcomes.'
    }
}

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Initialize database
def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0,
        full_name TEXT,
        profile_picture TEXT,
        location TEXT
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        image_path TEXT,
        result TEXT,
        confidence REAL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
    ''')
    conn.commit()
    conn.close()

# Initialize the database when the app starts
init_db()

# Initialize local YOLO model Instead of Hugging Face
try:
    # Use your downloaded .pt file from the HF Setup directory
    model_path = os.path.join(os.path.dirname(__file__), "HF Setup", "best-2.pt")
    model = YOLO(model_path)
except Exception as e:
    print(f"Error initializing local AI model: {e}")
    model = None

@app.context_processor
def inject_user():
    user = None
    if 'user_id' in session:
        conn = sqlite3.connect('database.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
        user = dict(cursor.fetchone() or {})
        conn.close()
    return dict(current_user=user)

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute('SELECT id, password, is_admin FROM users WHERE email = ?', (email,))
        user = cursor.fetchone()
        conn.close()
        
        if user and check_password_hash(user[1], password):
            session['user_id'] = user[0]
            session['email'] = email
            session['is_admin'] = bool(user[2])
            flash('Login successful!')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password')
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        full_name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        
        if not email or not password or not full_name:
            flash('All fields are required')
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password)
        
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        
        try:
            cursor.execute('INSERT INTO users (email, password, full_name) VALUES (?, ?, ?)', 
                          (email, hashed_password, full_name))
            conn.commit()
            flash('Registration successful! Please log in.')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Email already exists. Please choose another one.')
            return redirect(url_for('register'))
        finally:
            conn.close()
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('email', None)
    session.pop('is_admin', None)
    flash('You have been logged out')
    return redirect(url_for('index'))

from functools import wraps

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        conn = sqlite3.connect('database.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT is_admin FROM users WHERE id = ?', (session['user_id'],))
        user = cursor.fetchone()
        conn.close()
        if not user or not user['is_admin']:
            flash('Access denied. Administrator privileges required.', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/admin/users')
@admin_required
def admin_users():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users ORDER BY id DESC')
    users = cursor.fetchall()
    conn.close()
    return render_template('admin_users.html', users=users)

@app.route('/admin/scans')
@admin_required
def admin_scans():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('''
        SELECT p.*, u.email as user_email, u.full_name as user_name 
        FROM predictions p 
        JOIN users u ON p.user_id = u.id 
        ORDER BY p.timestamp DESC
    ''')
    scans = cursor.fetchall()
    conn.close()
    return render_template('admin_scans.html', scans=scans)

@app.route('/admin/files')
@admin_required
def admin_files():
    upload_dir = os.path.join(app.root_path, 'static', 'uploads')
    files = []
    if os.path.exists(upload_dir):
        for filename in os.listdir(upload_dir):
            file_path = os.path.join(upload_dir, filename)
            if os.path.isfile(file_path):
                files.append({
                    'name': filename,
                    'size': os.path.getsize(file_path),
                    'time': os.path.getmtime(file_path)
                })
    return render_template('admin_files.html', files=files)

@app.route('/admin/user/create', methods=['GET', 'POST'])
@admin_required
def admin_create_user():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        is_admin = 1 if request.form.get('is_admin') else 0
        full_name = request.form.get('full_name')
        
        if not email or not password:
            flash('Email and password are required.', 'error')
            return redirect(url_for('admin_create_user'))
            
        hashed_password = generate_password_hash(password)
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO users (email, password, is_admin, full_name) VALUES (?, ?, ?, ?)',
                         (email, hashed_password, is_admin, full_name))
            conn.commit()
            flash(f'User {email} created successfully.', 'success')
            return redirect(url_for('admin_users'))
        except sqlite3.IntegrityError:
            flash('Email already exists.', 'error')
        finally:
            conn.close()
            
    return render_template('admin_create_user.html')

@app.route('/admin/user/edit/<int:user_id>', methods=['GET', 'POST'])
@admin_required
def admin_edit_user(user_id):
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        is_admin = 1 if request.form.get('is_admin') else 0
        location = request.form.get('location')
        
        cursor.execute('UPDATE users SET full_name = ?, is_admin = ?, location = ? WHERE id = ?',
                     (full_name, is_admin, location, user_id))
        conn.commit()
        conn.close()
        flash('User updated successfully.', 'success')
        return redirect(url_for('admin_users'))
        
    cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('admin_users'))
        
    return render_template('admin_edit_user.html', target_user=user)

@app.route('/admin/user/delete/<int:user_id>')
@admin_required
def admin_delete_user(user_id):
    if user_id == session.get('user_id'):
        flash('Cannot delete your own account.', 'error')
        return redirect(url_for('admin_users'))
        
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM users WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()
    flash('User deleted successfully.', 'success')
    return redirect(url_for('admin_users'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please log in to access this page')
        return redirect(url_for('login'))
        
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM predictions WHERE user_id = ?', (session['user_id'],))
    total_analyses = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ? AND result = 'Normal case'", (session['user_id'],))
    normal_cases = cursor.fetchone()[0]
    
    abnormal_cases = total_analyses - normal_cases
    
    cursor.execute('SELECT AVG(confidence) FROM predictions WHERE user_id = ?', (session['user_id'],))
    avg_conf_row = cursor.fetchone()[0]
    avg_confidence = round(avg_conf_row, 1) if avg_conf_row else 0.0
    
    cursor.execute('SELECT * FROM predictions WHERE user_id = ? ORDER BY timestamp DESC LIMIT 5', 
                  (session['user_id'],))
    history = cursor.fetchall()

    # Real Monthly Trends calculation
    import datetime
    from collections import OrderedDict
    
    months = []
    normal_trend = []
    abnormal_trend = []
    
    for i in range(5, -1, -1):
        d = datetime.datetime.now() - datetime.timedelta(days=i*30)
        month_name = d.strftime('%b')
        month_val = d.strftime('%Y-%m')
        months.append(month_name)
        
        # Count normal for this month
        cursor.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ? AND result = 'Normal case' AND strftime('%Y-%m', timestamp) = ?", 
                      (session['user_id'], month_val))
        normal_trend.append(cursor.fetchone()[0])
        
        # Count abnormal for this month
        cursor.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ? AND result != 'Normal case' AND strftime('%Y-%m', timestamp) = ?", 
                      (session['user_id'], month_val))
        abnormal_trend.append(cursor.fetchone()[0])

    conn.close()
    
    return render_template('dashboard.html', 
                           history=history, 
                           stats={
                               'total': total_analyses,
                               'normal': normal_cases,
                               'abnormal': abnormal_cases,
                               'avg_confidence': avg_confidence
                           },
                           trends={
                               'labels': months,
                               'normal': normal_trend,
                               'abnormal': abnormal_trend
                           })

@app.route('/analyze', methods=['GET', 'POST'])
def analyze():
    if 'user_id' not in session:
        flash('Please log in to access this page')
        return redirect(url_for('login'))
        
    if model is None:
        flash('Error: AI service is currently unavailable')
        
    result = None
    recent_pred = None
    
    if request.method == 'POST':
        if model is None:
            flash('Cannot process image because AI service is unavailable')
            return redirect(request.url)
            
        if 'image' not in request.files:
            flash('No file part')
            return redirect(request.url)
        
        file = request.files['image']
        
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        
        if file:
            upload_dir = os.path.join(app.root_path, 'static', 'uploads')
            os.makedirs(upload_dir, exist_ok=True)
            
            unique_filename = f"{uuid.uuid4()}_{file.filename}"
            save_path = os.path.join(upload_dir, unique_filename)
            file.save(save_path)
            
            try:
                pred = model.predict(source=save_path)
                class_idx = pred[0].probs.top1
                confidence = float(pred[0].probs.top1conf.item()) * 100
                result = format_dict.get(int(class_idx), "Unknown")
                
                conn = sqlite3.connect('database.db')
                cursor = conn.cursor()
                cursor.execute('INSERT INTO predictions (user_id, image_path, result, confidence) VALUES (?, ?, ?, ?)',
                              (session['user_id'], unique_filename, result, confidence))
                conn.commit()
                conn.close()
                
                recent_pred = {
                    'image_path': unique_filename,
                    'result': result,
                    'confidence': confidence
                }
                
            except Exception as e:
                flash(f"Error during prediction: {str(e)}")
                result = "Error processing image"
                
    # Fetch history for the sidebar/recent predictions table in analyze.html
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM predictions WHERE user_id = ? ORDER BY timestamp DESC LIMIT 5', (session['user_id'],))
    history = cursor.fetchall()
    conn.close()
                
    return render_template('analyze.html', result=result, recent_pred=recent_pred, history=history, disease_info=DISEASE_INFO)

@app.route('/reports')
def reports():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM predictions WHERE user_id = ? ORDER BY timestamp DESC', (session['user_id'],))
    all_history = cursor.fetchall()
    conn.close()
    
    return render_template('reports.html', history=all_history)

@app.route('/history')
def history():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM predictions WHERE user_id = ? ORDER BY timestamp DESC', (session['user_id'],))
    all_history = cursor.fetchall()
    conn.close()
    
    return render_template('history.html', history=all_history)


@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        password = request.form.get('password')
        location = request.form.get('location')
        profile_picture = request.files.get('profile_picture')
        
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        
        if full_name:
            cursor.execute('UPDATE users SET full_name = ? WHERE id = ?', (full_name, session['user_id']))
            
        if location:
            cursor.execute('UPDATE users SET location = ? WHERE id = ?', (location, session['user_id']))
            
        if password:
            hashed = generate_password_hash(password)
            cursor.execute('UPDATE users SET password = ? WHERE id = ?', (hashed, session['user_id']))
            
        if profile_picture and profile_picture.filename != '':
            upload_dir = os.path.join(app.root_path, 'static', 'profile-uploads')
            os.makedirs(upload_dir, exist_ok=True)
            filename = secure_filename(f"{session['user_id']}_{uuid.uuid4()}_{profile_picture.filename}")
            profile_picture.save(os.path.join(upload_dir, filename))
            cursor.execute('UPDATE users SET profile_picture = ? WHERE id = ?', (filename, session['user_id']))
            
        conn.commit()
        conn.close()
        flash('Profile updated successfully!')
        return redirect(url_for('settings'))
        
    return render_template('settings.html')

if __name__ == '__main__':
    app.run(debug=True)