import os
from dotenv import load_dotenv
from gradio_client import Client
from huggingface_hub import login

# Load environment variables
load_dotenv()

# Login to Hugging Face
login(token=os.getenv('HUGGINGFACE_TOKEN'))

def predict_lung_condition(image_path):
    try:
        # Initialize the client
        client = Client("iSushant/Lung-Predictiion")
        
        # Make prediction
        result = client.predict(
            image_path,  # Pass the local image path
            api_name="/image_classifier"
        )
        return result
    except Exception as e:
        print(f"Error during prediction: {e}")
        return None

if __name__ == "__main__":
    # Test the prediction
    test_image = "path/to/your/test/image.jpg"  # Replace with actual test image path
    result = predict_lung_condition(test_image)
    print(f"Prediction result: {result}")
